
<div class="row">
    <div class="col-lg-12">
          <div class="padd">
            <!-- Adding Errors -->
            <?php
            if(isset($error)){
                echo '<div class="alert alert-danger"> Oh snap! Change a few things up and try submitting again. </div>';
            }
            
            $validation_errors = validation_errors();
            
            if(!empty($validation_errors))
            {
                echo '<div class="alert alert-danger"> Oh snap! '.$validation_errors.' </div>';
            }
            ?>
            
            <?php echo form_open($this->uri->uri_string(), array("class" => "form-horizontal", "role" => "form"));?>
            <?php
            if($live_stream->num_rows() > 0)
            {
                foreach ($live_stream->result() as $key) {
                    # code...

                    $live_stream_id = $key->live_stream_id;
                    $event_name = $key->event_name;
                    $event_description = $key->event_description;
                    $activate_stream = $key->activate_stream;
                    $streamer_link = $key->streamer_link;
                    $created = $key->created;
                    $created_by = $key->created_by;
                    $users = $key->users;
                    $streaming_status = $key->streaming_status;
                }
                ?>
                <div class="row">
                    <div class="row ">
                        <div class="col-lg-6">
                            <!-- post category -->
                            <!-- First Name -->
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Event name</label>
                                <div class="col-lg-8">
                                    <input type="text" name="event_name" class="form-control" placeholder=" Name of event" value="<?php echo $event_name;?>" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Live stream link</label>
                                <div class="col-lg-8">
                                    <input type="text" name="event_link" class="form-control" placeholder=" Link value" value="<?php echo $streamer_link;?>" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Activate live stream?</label>
                                <div class="col-lg-8">

                                    <div class="radio">
                                        <label>
                                            <?php
                                            if($activate_stream == 1){echo '<input id="optionsRadios1" type="radio" checked value="1" name="activate_stream">';}
                                            else{echo '<input id="optionsRadios1" type="radio" value="1" name="activated">';}
                                            ?>
                                            Yes
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <?php
                                            if($activate_stream == 0){echo '<input id="optionsRadios1" type="radio" checked value="0" name="activated">';}
                                            else{echo '<input id="optionsRadios1" type="radio" value="0" name="activated">';}
                                            ?>
                                            No
                                        </label>
                                    </div>
                                </div>
                             </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Event Description</label>
                                <div class="col-lg-8">
                                    <textarea name="event_description" class="form-control" rows="7" placeholder=" description"/> </textarea>
                                </div>
                            </div>
                            <div class="form-actions center-align">
                                <button class="submit btn btn-success" type="submit">
                                   Stop Braodcasting

                                </button>
                            </div>
                          
                        </div>
                        <div class="col-lg-6">
                            <!-- post category -->
                            <!-- First Name -->
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <iframe width="100%" height="315" src="http://www.youtube.com/embed/<?php echo $streamer_link;?>" frameborder="0" allowfullscreen></iframe>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                <?php

            }
            else
            {
                ?>
                <div class="row">
                    <div class="row ">
                        <div class="col-lg-6">
                            <!-- post category -->
                            <!-- First Name -->
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Event name</label>
                                <div class="col-lg-8">
                                    <input type="text" name="event_name" class="form-control" placeholder=" Name of event"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Live stream link</label>
                                <div class="col-lg-8">
                                    <input type="text" name="event_link" class="form-control" placeholder=" Link value"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Activate live stream?</label>
                                <div class="col-lg-8">
                                    <input type="radio" name="activated"  checked value="1"> Yes
                                    <input type="radio" name="activated"  value="2"> No
                                </div>
                             </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Event Description</label>
                                <div class="col-lg-8">
                                    <textarea name="event_description" class="form-control" rows="7" placeholder=" description"/> </textarea>
                                </div>
                            </div>
                            <div class="form-actions center-align">
                                <button class="submit btn btn-success" type="submit">
                                    Save and start bradcasting
                                </button>
                            </div>
                          
                        </div>
                        <div class="col-lg-6">
                            <!-- post category -->
                            <!-- First Name -->
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <iframe width="100%" height="315" src="http://www.youtube.com/embed/8AaLMBz283w" frameborder="0" allowfullscreen></iframe>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                <?php

            }
            ?>
             
            <?php echo form_close();?>
		</div>
    </div>
</div>
