<?php   if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once "./application/modules/admin/controllers/admin.php";

class Live_streaming extends admin {
	
	function __construct()
	{
		parent:: __construct();
		$this->load->model('users_model');
		$this->load->model('live_streaming_model');
	}
    
	/*
	*
	*	Default action is to show all the users
	*
	*/
	public function index() 
	{

		//open the add new user page
		//form validation rules
		$this->form_validation->set_rules('event_name', 'Event Name', 'required|xss_clean');
		$this->form_validation->set_rules('event_link', 'Event link', 'required|xss_clean');
		$this->form_validation->set_rules('activated', 'Activated', 'xss_clean');
		$this->form_validation->set_rules('event_description', 'Description', 'xss_clean');
		
		//if form has been submitted
		if ($this->form_validation->run())
		{
			//check if user has valid login credentials
			if($this->live_streaming_model->add_event_streaming())
			{
				redirect('all-users');
			}
			
			else
			{
				$data['error'] = 'Unable to add user. Please try again';
			}
		}
		$v_data['live_stream'] = $this->live_streaming_model->get_now_streaming_meeting();
		
		//open the add new user page
		$data['title'] = 'Streaming now';
		$data['content'] = $this->load->view('live_streaming/streaming', $v_data, TRUE);
		$this->load->view('templates/general_admin', $data);
	}
	public function add_live_stream()
	{

		//form validation rules
		$this->form_validation->set_rules('event_name', 'Event Name', 'required|xss_clean');
		$this->form_validation->set_rules('event_link', 'Event link', 'required|xss_clean');
		$this->form_validation->set_rules('activated', 'Activated', 'xss_clean');
		$this->form_validation->set_rules('event_description', 'Description', 'xss_clean');
		
		//if form has been submitted
		if ($this->form_validation->run())
		{
			//check if user has valid login credentials
			if($this->live_streaming_model->add_event_streaming())
			{
				redirect('all-users');
			}
			
			else
			{
				$data['error'] = 'Unable to add user. Please try again';
			}
		}
		$v_data['live_stream'] = $this->live_streaming_model->get_now_streaming_meeting();
		
		//open the add new user page
		$data['title'] = 'Streaming now';
		$data['content'] = $this->load->view('live_streaming/streaming', $v_data, TRUE);
		$this->load->view('templates/general_admin', $data);
	}
}