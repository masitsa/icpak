<div class="container main-container headerOffset">
  
  <div class="row innerPage">
    <div class="col-lg-12 col-md-12 col-sm-12">
      <div class="row userInfo">
        
        <p class="lead text-center"> Your order has been successfully placed<br/><a class="btn btn-default" href="<?php echo site_url().'products/all-products';?>"> <i class="fa fa-arrow-right"></i> &nbsp; Continue Shopping </a> </p>
        
        
      </div>  <!--/row end-->
    </div>
  </div> <!--/.innerPage-->
  <div style="clear:both">  </div>
</div><!-- /.main-container -->


<div class="gap"> </div>