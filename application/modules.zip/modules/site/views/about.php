 <!-- Join  -->
        <div class="content light-grey-background">
        	<div class="container">
        		<div class="search-flights">
                	<div class="divider-line"></div>
                	<h1 class="center-align">About In Store Look</h1>
                	<div class="divider-line" style="margin-bottom:2%;"></div>
                    
                    <p>
                    	In Store Look was created and developed by Bryn Haggarty, to provide local business the tools and support for online sales while providing customers with the ability to not only buy local product and support their local area but also search specifically to their geographical needs.
                    </p>
                    
                    <p>
                    	Established in 2013 and launched in Bryn's local area of Castle Hill.
                    </p>
                </div>
                
        		<div class="search-flights">
                	<div class="divider-line"></div>
                	<h1 class="center-align">Why Us</h1>
                	<div class="divider-line" style="margin-bottom:2%;"></div>
                    
                    <p>
                    	In store look was established to improve connections between local business and their surrounding customer base through a localised online marketplace.
                    </p>
                    
                    <p>
                    	By allowing customers to search within a specified location like the current suburb, they can narrow down their search to specific stores, products and the nearest location.
                    </p>
                    
                    <p>
                    	We believe that there is a need to increase customer awareness of the benefits of buying not only within Australia but within their local community and we strive to make this a common reality. Supporting communities through supporting local businesses.
                    </p>
                </div>
            </div>
        </div>
        <!-- End Join -->