 <footer class="footer">
    <strong>ICPAK - Kenya </strong> v0.1 &copy; Copyright 2015
</footer>